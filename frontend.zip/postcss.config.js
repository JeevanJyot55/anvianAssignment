// postcss.config.js
export default {
  plugins: {
    '@tailwindcss/postcss': {}, // ← use the new plugin package
    autoprefixer: {}
  }
}
